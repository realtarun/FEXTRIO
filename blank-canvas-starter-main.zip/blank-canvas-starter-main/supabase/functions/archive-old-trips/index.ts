import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.86.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    )

    // Calculate start of current month
    const now = new Date()
    const startOfCurrentMonth = new Date(now.getFullYear(), now.getMonth(), 1)
    const startOfCurrentMonthISO = startOfCurrentMonth.toISOString().split('T')[0]

    console.log('Archiving trips older than:', startOfCurrentMonthISO)

    // Update trips that are older than current month and not already archived
    const { data, error } = await supabaseClient
      .from('trips')
      .update({ is_archived: true })
      .lt('date', startOfCurrentMonthISO)
      .eq('is_archived', false)
      .select()

    if (error) {
      console.error('Error archiving trips:', error)
      throw error
    }

    console.log('Archived trips:', data?.length || 0)

    return new Response(
      JSON.stringify({
        success: true,
        archivedCount: data?.length || 0,
        message: `Successfully archived ${data?.length || 0} trips`,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )
  } catch (error) {
    console.error('Error in archive-old-trips function:', error)
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      },
    )
  }
})
