-- Performance Optimization: Add indexes for faster queries

-- Index for trips by vehicle and date (most common query pattern)
CREATE INDEX IF NOT EXISTS idx_trips_vehicle_date 
ON trips(vehicle_id, date DESC);

-- Index for trips by vehicle and archived status
CREATE INDEX IF NOT EXISTS idx_trips_vehicle_archived 
ON trips(vehicle_id, is_archived);

-- Index for trips filtering by date range
CREATE INDEX IF NOT EXISTS idx_trips_date_range 
ON trips(date);

-- Index for vehicle ownership queries
CREATE INDEX IF NOT EXISTS idx_vehicles_user 
ON vehicles(user_id);

-- Index for vehicle access lookups
CREATE INDEX IF NOT EXISTS idx_vehicle_users_lookup 
ON vehicle_users(vehicle_id, user_id);

-- Index for user roles
CREATE INDEX IF NOT EXISTS idx_user_roles_lookup 
ON user_roles(user_id, role);

-- Add composite index for archived trips with date filtering
CREATE INDEX IF NOT EXISTS idx_trips_archived_date 
ON trips(vehicle_id, is_archived, date DESC) 
WHERE is_archived = true;