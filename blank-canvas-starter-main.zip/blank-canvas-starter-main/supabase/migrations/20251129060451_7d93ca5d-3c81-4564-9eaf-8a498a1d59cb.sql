-- Create app_role enum for role-based access control
CREATE TYPE public.app_role AS ENUM ('owner', 'manager', 'viewer');

-- Create profiles table for additional user information
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create user_roles table for role management
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create vehicle_users table for mapping users to vehicles with roles
CREATE TABLE public.vehicle_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID REFERENCES public.vehicles(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL DEFAULT 'viewer',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(vehicle_id, user_id)
);

ALTER TABLE public.vehicle_users ENABLE ROW LEVEL SECURITY;

-- Add user_id to vehicles table
ALTER TABLE public.vehicles ADD COLUMN user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;

-- Add isArchived to trips table
ALTER TABLE public.trips ADD COLUMN is_archived BOOLEAN DEFAULT false;

-- Create index for archived trips queries
CREATE INDEX idx_trips_archived ON public.trips(vehicle_id, is_archived, date);

-- Create security definer function to check if user has a specific role
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Create security definer function to check if user has access to a vehicle
CREATE OR REPLACE FUNCTION public.has_vehicle_access(_user_id UUID, _vehicle_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.vehicles v
    LEFT JOIN public.vehicle_users vu ON vu.vehicle_id = v.id
    WHERE v.id = _vehicle_id
      AND (v.user_id = _user_id OR vu.user_id = _user_id)
  )
$$;

-- Create security definer function to check if user can modify a vehicle
CREATE OR REPLACE FUNCTION public.can_modify_vehicle(_user_id UUID, _vehicle_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.vehicles v
    LEFT JOIN public.vehicle_users vu ON vu.vehicle_id = v.id
    WHERE v.id = _vehicle_id
      AND (
        v.user_id = _user_id 
        OR (vu.user_id = _user_id AND vu.role = 'owner')
      )
  )
$$;

-- Create security definer function to check if user can modify trips
CREATE OR REPLACE FUNCTION public.can_modify_trips(_user_id UUID, _vehicle_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.vehicles v
    LEFT JOIN public.vehicle_users vu ON vu.vehicle_id = v.id
    WHERE v.id = _vehicle_id
      AND (
        v.user_id = _user_id 
        OR (vu.user_id = _user_id AND vu.role IN ('owner', 'manager'))
      )
  )
$$;

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Insert profile
  INSERT INTO public.profiles (id, display_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.email)
  );
  
  -- Assign default 'owner' role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'owner');
  
  RETURN NEW;
END;
$$;

-- Create trigger for new user signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Update trigger for profiles
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- RLS Policies for profiles
CREATE POLICY "Users can view all profiles"
  ON public.profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Only owners can manage roles"
  ON public.user_roles FOR ALL
  USING (public.has_role(auth.uid(), 'owner'));

-- RLS Policies for vehicles
DROP POLICY IF EXISTS "Anyone can view vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Anyone can create vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Anyone can update vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Anyone can delete vehicles" ON public.vehicles;

CREATE POLICY "Users can view vehicles they have access to"
  ON public.vehicles FOR SELECT
  USING (
    auth.uid() = user_id 
    OR public.has_vehicle_access(auth.uid(), id)
  );

CREATE POLICY "Authenticated users can create vehicles"
  ON public.vehicles FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update vehicles they own"
  ON public.vehicles FOR UPDATE
  USING (public.can_modify_vehicle(auth.uid(), id));

CREATE POLICY "Users can delete vehicles they own"
  ON public.vehicles FOR DELETE
  USING (public.can_modify_vehicle(auth.uid(), id));

-- RLS Policies for vehicle_users
CREATE POLICY "Users can view vehicle_users for their vehicles"
  ON public.vehicle_users FOR SELECT
  USING (public.has_vehicle_access(auth.uid(), vehicle_id));

CREATE POLICY "Vehicle owners can manage vehicle_users"
  ON public.vehicle_users FOR ALL
  USING (public.can_modify_vehicle(auth.uid(), vehicle_id));

-- RLS Policies for trips
DROP POLICY IF EXISTS "Anyone can view trips" ON public.trips;
DROP POLICY IF EXISTS "Anyone can create trips" ON public.trips;
DROP POLICY IF EXISTS "Anyone can update trips" ON public.trips;
DROP POLICY IF EXISTS "Anyone can delete trips" ON public.trips;

CREATE POLICY "Users can view trips for their vehicles"
  ON public.trips FOR SELECT
  USING (public.has_vehicle_access(auth.uid(), vehicle_id));

CREATE POLICY "Users can create trips for vehicles they manage"
  ON public.trips FOR INSERT
  WITH CHECK (public.can_modify_trips(auth.uid(), vehicle_id));

CREATE POLICY "Users can update trips for vehicles they manage"
  ON public.trips FOR UPDATE
  USING (public.can_modify_trips(auth.uid(), vehicle_id));

CREATE POLICY "Users can delete trips for vehicles they manage"
  ON public.trips FOR DELETE
  USING (public.can_modify_trips(auth.uid(), vehicle_id));