-- Create vehicles table
CREATE TABLE public.vehicles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  owner_name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create trips table
CREATE TABLE public.trips (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  cash NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (cash >= 0),
  earning NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (earning >= 0),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for better query performance
CREATE INDEX trips_vehicle_date_idx ON public.trips(vehicle_id, date);

-- Enable Row Level Security
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trips ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (MVP - no auth yet)
CREATE POLICY "Anyone can view vehicles" 
ON public.vehicles 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can create vehicles" 
ON public.vehicles 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can update vehicles" 
ON public.vehicles 
FOR UPDATE 
USING (true);

CREATE POLICY "Anyone can delete vehicles" 
ON public.vehicles 
FOR DELETE 
USING (true);

CREATE POLICY "Anyone can view trips" 
ON public.trips 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can create trips" 
ON public.trips 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can update trips" 
ON public.trips 
FOR UPDATE 
USING (true);

CREATE POLICY "Anyone can delete trips" 
ON public.trips 
FOR DELETE 
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_vehicles_updated_at
BEFORE UPDATE ON public.vehicles
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_trips_updated_at
BEFORE UPDATE ON public.trips
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();